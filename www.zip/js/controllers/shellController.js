dempsey.controller('shellController',
    function shellController($scope) {


    });